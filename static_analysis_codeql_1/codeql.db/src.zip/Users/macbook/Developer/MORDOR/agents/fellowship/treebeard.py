from __future__ import annotations

import os

from agents.gates import skip_llm
from agents.schemas import TreebeardSandboxSchema
from tools.openrouter_client import chat_structured


def verify_sandbox() -> bool:
    docker_ok = os.system("docker info > /dev/null 2>&1") == 0
    return docker_ok


def run_in_sandbox(binary_path: str, use_llm_fallback: bool = True, tier: str = "standard") -> dict:
    if not verify_sandbox():
        if not use_llm_fallback or skip_llm(tier):
            return {"status": "sandbox_not_available", "results": {}, "container_id": None}
        return _sandbox_llm_analysis(binary_path)

    return {"status": "sandbox_ready", "results": {"container": "mordor-sandbox"}, "container_id": None}


def _sandbox_llm_analysis(binary_path: str) -> dict:
    messages = [
        {
            "role": "system",
            "content": "You are TREEBEARD, a Docker sandbox isolation agent. "
            "Given a binary path, describe expected sandbox execution behavior: "
            "filesystem activity, network connections, process tree, and registry changes.",
        },
        {
            "role": "user",
            "content": f"Simulate sandbox analysis for: {binary_path}",
        },
    ]
    result = chat_structured(
        messages, schema=TreebeardSandboxSchema,
        temperature=0.3, agent_name="treebeard", phase="validate",
    )
    if result is None:
        return {"status": "sandbox_not_available", "results": {}, "container_id": None}
    return result.model_dump()
