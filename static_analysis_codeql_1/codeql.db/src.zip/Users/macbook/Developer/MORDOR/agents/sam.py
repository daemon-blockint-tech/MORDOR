from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


class CaseMemory:
    def __init__(self, case_dir: str):
        self.case_dir = Path(case_dir)

    def exists(self) -> bool:
        return self.case_dir.exists()

    def write_artifact(self, name: str, data: Any) -> None:
        self.case_dir.mkdir(parents=True, exist_ok=True)
        path = self.case_dir / name
        if isinstance(data, (dict, list)):
            with open(path, "w") as f:
                json.dump(data, f, indent=2)
        else:
            path.write_text(str(data))

    def read_artifact(self, name: str) -> Any:
        path = self.case_dir / name
        if not path.exists():
            return None
        if name.endswith(".json"):
            return json.loads(path.read_text())
        return path.read_text()

    def list_artifacts(self) -> list[str]:
        if not self.exists():
            return []
        return sorted(f.name for f in self.case_dir.iterdir() if f.is_file())

    def resume_state(self) -> dict[str, Any] | None:
        state_path = self.case_dir / ".pipeline_state.json"
        if state_path.exists():
            return json.loads(state_path.read_text())
        return None

    def save_state(self, state: dict[str, Any]) -> None:
        self.write_artifact(".pipeline_state.json", state)
