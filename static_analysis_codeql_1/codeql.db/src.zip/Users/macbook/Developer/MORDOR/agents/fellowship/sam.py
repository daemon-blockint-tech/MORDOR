from __future__ import annotations

import json
from pathlib import Path


def load_case(case_dir: str) -> dict | None:
    path = Path(case_dir) / "metadata.json"
    if path.exists():
        return json.loads(path.read_text())
    return None


def write_artifact(case_dir: str, name: str, data: dict | list | str) -> Path:
    path = Path(case_dir) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, (dict, list)):
        path.write_text(json.dumps(data, indent=2))
    else:
        path.write_text(data)
    return path


def list_artifacts(case_dir: str) -> list[str]:
    base = Path(case_dir)
    if not base.exists():
        return []
    return sorted(f.relative_to(base).as_posix() for f in base.rglob("*") if f.is_file())
