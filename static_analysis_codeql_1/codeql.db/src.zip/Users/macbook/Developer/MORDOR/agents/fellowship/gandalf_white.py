from __future__ import annotations

from graph.state import CaseState


def write_report(state: CaseState) -> str:
    sections = [
        "# MORDOR Final Analysis Report",
        "",
        f"## Sample: `{state.get('sha256', 'unknown')}`",
        "",
        f"**Overall Confidence**: {state.get('confidence_overall', 0.0):.0f}%",
        "",
        "## Hypotheses",
    ]

    for h in state.get("hypotheses", []):
        sections.append(f"- **{h.get('category', 'unknown')}**: {h.get('description', '')}")
        sections.append(f"  - Confidence: {h.get('confidence', 0.0):.0f}%")

    sections.append("")
    sections.append("## Indicators of Compromise")

    for ioc in state.get("iocs", []):
        sections.append(f"- [{ioc.get('type', 'unknown')}] `{ioc.get('value', '')}`")

    sections.append("")
    sections.append("## Phase Results")

    for pr in state.get("phase_results", []):
        sections.append(f"- **{pr.get('phase', 'unknown')}**: {pr.get('status', 'unknown')}")

    return "\n".join(sections)
