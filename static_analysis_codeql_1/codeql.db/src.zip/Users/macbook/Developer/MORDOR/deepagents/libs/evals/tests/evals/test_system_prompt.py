"""Unit test for system prompt passthrough.

Verifies that a custom system prompt provided via create_deep_agent
is reflected in the agent's response. This is an SDK integration test,
not a model capability eval.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from deepagents import create_deep_agent

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel

from tests.evals.utils import (
    TrajectoryScorer,
    final_text_contains,
    run_agent,
)

pytestmark = [pytest.mark.eval_category("unit_test"), pytest.mark.eval_tier("baseline")]
"""Apply unit_test category and baseline tier to all tests in this module."""


@pytest.mark.langsmith
def test_custom_system_prompt(model: BaseChatModel) -> None:
    """Custom system prompt is reflected in the answer."""
    agent = create_deep_agent(model=model, system_prompt="Your name is Foo Bar.")
    run_agent(
        agent,
        query="what is your name",
        model=model,
        # 1 step: answer directly.
        # 0 tool calls: no files/tools needed.
        scorer=TrajectoryScorer()
        .expect(agent_steps=1, tool_call_requests=0)
        .success(final_text_contains("Foo Bar")),
    )
